import { getAllProfiles } from "./api/services/profielService.js";
import { getProfileElement } from "./api/views/profielView.js";
import { getAllActiviteiten } from "./api/services/activiteitService.js";
import { getActiviteitElement } from "./api/views/activiteitView.js";


