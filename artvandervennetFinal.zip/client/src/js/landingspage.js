setTimeout(() => {
    window.location.href = "./home/";
}, 500)