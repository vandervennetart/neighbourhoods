# neighbourhoods

de client staat op plesk onder : https://neighbourhoods.artvandervennet.ikdoeict.be/
de server staat op plesk onder : https://neighbourhoodsAPI.artvandervennet.ikdoeict.be/

## accounts
Ik heb ook een volledig user systeem met jwt gemaakt.

Je moet niet ingelogd zijn om de website te gebruiken

Je kan u inloggen als al bestaande account of een nieuw account maken

Een account heeft een profielfoto die het kan wijzigen.

### Admin
    admin gegevens:
    admin@admin.com
    Azerty123

De admin kan accounts en activiteiten verwijderen. Als een account wordt verwijderd worden ook alle activiteiten georganiseerd door dat account verwijderd.
De admin wordt bewust niet getoont tussen de bewoners want ik vind de admin niet echt een bewoner. Meer een beheerder.

## activiteit
Een activiteit kan worden aangemaakt door een ingelogde gebruiker. 
Als je niet ingelogd bent wordt je verwezen naar de loginpagina.

In de code verwijs ik naar een activiteit beide als activiteit en post (niet super handig... maarja)

